class DayZCreatureType : EntityAIType
{

};
