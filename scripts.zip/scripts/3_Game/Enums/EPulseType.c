enum EPulseType
{
	REGULAR,
	IRREGULAR,
}